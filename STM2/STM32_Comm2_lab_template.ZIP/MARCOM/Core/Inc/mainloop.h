/**
*****************************************************************************
** Communication lab - mainloop.h
** Header for the main loop
*****************************************************************************
*/
#pragma once
#ifndef _MAINLOOP_H__
#define _MAINLOOP_H__

void MainLoop_Init();
void MainLoop_Go();

#endif
